package ru.mastercond;

public class TovarID {
  
   String s;

   public String setTovarID(String s)
   {
      this.s=s;
      return s;
   }
   
   public String getTovarID()
   {       
     return s;     
   }
  
}

package ru.mastercond;

public class TextStr {

   String s;

   public String setTextStr(String s) 
   {
      this.s=s;
      return s;
   }
   
   public String getTextStr()     
   {       
     return s;     
   }
  
}

package ru.mastercond;

public class KontragentSName {

String s;

   public String setKontragentSName(String s) 
   {
      this.s=s;
      return s;
   }
   
   public String getKontragentSName()     
   {       
     return s;     
   }

}
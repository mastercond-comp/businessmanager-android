package ru.mastercond;

public class SdelkaID {
  
   String s;

   public String setSdelkaID(String s) 
   {
      this.s=s;
      return s;
   }
   
   public String getSdelkaID()     
   {       
     return s;     
   }
  
}

package ru.mastercond;

public class AutoID {
  
   String s;

   public String setAutoID(String s)
   {
      this.s=s;
      return s;
   }
   
   public String getAutoID()
   {       
     return s;     
   }
  
}

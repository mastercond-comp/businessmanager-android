package ru.mastercond;

public class SiteSName {

String s;

   public String setSiteSName(String s)
   {
      this.s=s;
      return s;
   }
   
   public String getSiteSName()
   {       
     return s;     
   }

}